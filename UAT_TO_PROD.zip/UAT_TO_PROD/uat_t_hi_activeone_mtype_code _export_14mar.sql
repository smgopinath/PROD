-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: ABCDUATDB
-- ------------------------------------------------------
-- Server version	8.0.31-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `t_hi_activeone_mtype_code`
--

INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (1,'AH01','Individual',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (2,'AH02','Self + Spouse',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (3,'AH03','Self + Kid1',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (4,'AH06','Self + Kid1 + Kid2',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (5,'AH10','Self + Kid1 + Kid2 + Kid3',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (6,'AH14','Self + Spouse + Kid1',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (7,'AH19','Self + Spouse + Kid1 + Kid2',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (8,'AH34','Self + Spouse + Kid1 + Kid2 + Kid3',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (9,'SH02','Father + Mother',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (10,'GH02','Father in Law + Mother in Law',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (11,'AH129','Self + Kid1 + Kid2 + Kid3 + Kid4',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (12,'AH132','Self + Liv In',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (13,'AH133','Self + Liv In + Kid1',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (14,'AH134','Self + Liv In + Kid1 + Kid2',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (15,'AH135','Self + Liv In + Kid1 + Kid2 + Kid3',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (16,'AH136','Self + Liv In + Kid1 + Kid2 + Kid3 + Kid4',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (17,'AH140','Self + Spouse + Kid1 + Kid2 + Kid3 + Kid4',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (18,'M147','Spouse + Kid1',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (19,'M163','Spouse + Kid1 + Kid2',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (20,'M179','Spouse + Kid1 + Kid2 + Kid3',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (21,'AH141','Spouse + Kid1 + Kid2 + Kid3 + Kid4',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (22,'AH146','Liv In + Kid1',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (23,'AH147','Liv In + Kid1 + Kid2',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (24,'AH148','Liv In + Kid1 + Kid2 + Kid3',7200,_binary '');
INSERT INTO `t_hi_activeone_mtype_code` (`activone_id`, `member_type_code`, `member_type`, `product_code`, `active`) VALUES (25,'AH149','Liv In + Kid1 + Kid2 + Kid3 + Kid4',7200,_binary '');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
