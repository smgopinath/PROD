-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: ABCDUATDB
-- ------------------------------------------------------
-- Server version	8.0.31-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `t_product_plan_master`
--

INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (1,'Activ Fit Plus','7100','7100100002',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (2,'Activ Fit Preferred','7100','7100100004',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (3,'Activ Health Platinum Enhanced','6212','6212100003',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (4,'Activ Health Platinum Essential','6212','6212100004',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (5,'Active Care -Senior Citizen Classic','5221','5221100002',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (6,'Super Health Plus Top up','5223','5223100001',4,'N');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (7,'Activ Assure Diamond + Super Top Up Plan B','5223 | 4226','5223100002 | 4226100001',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (8,'Activ Assure Diamond','4226','4226100001',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (9,'Activ Secure-Critical Illness Plan1','4217','4217100001',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (10,'Activ Secure-Critical Illness Plan2','4217','4217100002',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (11,'Activ Secure-Critical Illness Plan3','5223','5223100001',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (12,'Super Health Plus Top up Plan A','5223','5223100001',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (13,'Super Health Plus Top up Plan B','5223','5223100002',4,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (14,'ABSLI Digishield plan','1000','1000',14,'Y');
INSERT INTO `t_product_plan_master` (`plan_id`, `plan_name`, `product_code`, `plan_code`, `lob_id`, `active`) VALUES (15,'Activ One Max','7200','MASSMARKET',4,'Y');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
