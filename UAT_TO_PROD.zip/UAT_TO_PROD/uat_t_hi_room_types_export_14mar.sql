-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: ABCDUATDB
-- ------------------------------------------------------
-- Server version	8.0.31-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `t_hi_room_types`
--

INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (1,'FamilyDiscount',2.00,5.00,'FD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (2,'FamilyDiscount',3.00,10.00,'FD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (3,'FamilyDiscount',3.00,10.00,'FD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (4,'LongTermPolicyDiscount',2.00,7.50,'LTPD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (5,'LongTermPolicyDiscount',3.00,10.00,'LTPD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (6,'LongTermPolicyDiscount',2.00,7.50,'LTPD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (7,'LongTermPolicyDiscount',3.00,10.00,'LTPD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (8,'LongTermPolicyDiscount',2.00,7.50,'LTPD',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (9,'Affiliate Employee Discount',0.10,10.00,'AED',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (10,'Loading_Monthly',0.06,6.00,'LDM',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (11,'Loading_Quarterly',0.05,5.00,'LDQ',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (12,'Loading_Semi Annually',0.03,3.00,'LDS',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (13,'Employee Discount',10.00,10.00,'EMP',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (14,'PPN Discount',10.00,10.00,'PPN',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (15,'ROOM_TYPE',110.00,10.00,'ANY',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (16,'ROOM_TYPE',90.00,10.00,'SHARED',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (17,'COVER',20.00,20.00,'CO_PAYMENT',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (18,'Zone',1.00,0.00,'Zone','Platinum-Premier',NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (19,'Zone',1.00,0.00,'Zone','Platinum-Premier',6212);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (20,'Zone',2.00,9.00,'Zone','Platinum-Premier',6212100002);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (21,'Zone',3.00,23.00,'Zone','Platinum-Premier',6212100002);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (22,'Zone',1.00,0.00,'Zone','Platinum- Essential',6212100004);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (23,'Zone',2.00,9.00,'Zone','Platinum- Essential',6212100004);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (24,'Zone',3.00,21.50,'Zone','Platinum- Essential',6212100004);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (25,'Zone',1.00,0.00,'Zone','Platinum- Enhanced',6212100003);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (26,'Zone',2.00,10.00,'Zone','Platinum- Enhanced',6212100003);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (27,'Zone',3.00,23.50,'Zone','Platinum- Enhanced',6212100003);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (28,'Zone',1.00,0.00,'Zone','Platinum-Premier',6212100002);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (29,'ROOM_TYPE',100.00,0.00,'SINGLE',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (30,'ROOM_RENT_TYPE',85.00,15.00,'Shared Room',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (31,'ROOM_RENT_TYPE',92.50,7.50,'Single Private Room',NULL,NULL);
INSERT INTO `t_hi_room_types` (`room_type_id`, `discount_name`, `room_range`, `room_value`, `discount_code`, `product_name`, `schema_code`) VALUES (32,'ROOM_RENT_TYPE',100.00,0.00,'Actuals up to Base Sum Insured',NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
