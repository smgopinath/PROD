-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: ABCDUATDB
-- ------------------------------------------------------
-- Server version	8.0.31-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `t_lob_master`
--

INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (1,'PL','Personal Loan',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (2,'BL','Business Loan',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (3,'HL','Home Loan',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (4,'HI','Health Insurance',16,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (5,'LIT','Life Insurance Term',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (6,'LIC','Life Insurance Child',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (7,'LIS','Life Insurance Savings',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (8,'LIR','Life Insurance Retirement',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (9,'LIU','Life Insurance Ulip',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (10,'MF','Mutual Fund',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (11,'HLBT','HomeLoan Balance Transfer',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (12,'HLLAP','HomeLoan Loan Against Property',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (13,'HLTOPUP','HomeLoan Top Up',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (14,'LI','Life Insurance',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (15,'LINAP','Nischit Aayush Plan',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (16,'DHA','Digital Health Assessment',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (17,'Stocks','Stocks',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (18,'HI Topup','HI Topup',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (19,'Digigold','Digigold',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (20,'PFC','Portfolio Consolidator',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (21,'CS','Credit Score',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (22,'LA','Login Activation\n	',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (23,'Deposit','Deposit',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (24,'LIASP','Assured Savings Plan',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (25,'UPI','Unified Payment Interface',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (26,'LISTP','Salaried Term Plan',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (27,'Credit Card','Credit Card',NULL,_binary '');
INSERT INTO `t_lob_master` (`id`, `lob`, `desc`, `no_ofsteps`, `active`) VALUES (28,'Home','Home (Landing Page)',NULL,_binary '');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
