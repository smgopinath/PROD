ALTER TABLE t_dha_pdf_report DROP COLUMN pubsub_message_id;
ALTER TABLE t_dha_pdf_report DROP COLUMN pdf_gcs_file_path;


DROP INDEX ix_scanid;
CREATE INDEX ix_scanid ON t_dha_pdf_report(scan_id);