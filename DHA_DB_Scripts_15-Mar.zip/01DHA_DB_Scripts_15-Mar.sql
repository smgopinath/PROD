alter table t_dha_pdf_report add column (pubsub_message_id varchar(45) comment 'To store the PDF in GCP storage',
 pdf_gcs_file_path varchar(1500) comment 'To store the PDF URL from GCP storage');

CREATE UNIQUE INDEX ix_scanid ON t_dha_pdf_report(scan_id); 
